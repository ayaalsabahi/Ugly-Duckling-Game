using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyFlee : MonoBehaviour
{
    /*enemyFlee: This script detects if an enemy is within the radius of the player 
                 as well as activating a fleeAI when it is */

    private void isNear()
    {

    }

    private void fleeMode()
    {

    }
}
